from flask import Flask, render_template, request, jsonify, send_file
import subprocess
import os
import json
import re
import threading
import time
import io
import urllib.request

app = Flask(__name__)

# Store download progress for each session
download_progress = {}

def parse_yt_dlp_progress(line):
    """Parse yt-dlp progress output"""
    patterns = [
        r'\[download\]\s+(\d+\.\d+)% of\s+~?\s*(\d+\.\d+)([KMGT]i?B)?.*?ETA (\d+:\d+)',
        r'\[download\]\s+(\d+\.\d+)%.*?ETA (\d+:\d+)',
        r'\[download\]\s+([\w\s.-]+) has already been downloaded',
        r'\[download\]\s+Destination: ([\w\s.-]+)'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, line)
        if match:
            if 'has already been downloaded' in line:
                return {'status': 'completed', 'filename': match.group(1)}
            elif 'Destination:' in line:
                return {'status': 'started', 'filename': match.group(1)}
            elif len(match.groups()) >= 4:
                return {
                    'progress': float(match.group(1)),
                    'size': match.group(2) + (match.group(3) or ''),
                    'eta': match.group(4),
                    'status': 'downloading'
                }
            elif len(match.groups()) >= 2:
                return {
                    'progress': float(match.group(1)),
                    'eta': match.group(2),
                    'status': 'downloading'
                }
    
    if '100%' in line and 'download' in line:
        return {'progress': 100, 'status': 'completed'}
    
    return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/download', methods=['POST'])
def download():
    data = request.json
    url = data.get('url', '')
    options = data.get('options', {})
    session_id = data.get('session_id')
    
    if not url:
        return jsonify({'error': 'URL is required'}), 400
    
    cmd = ['yt-dlp', '--newline', '--console-title']
    
    if options.get('format'):
        cmd.extend(['-f', options['format']])
    
    if options.get('output_template'):
        cmd.extend(['-o', options['output_template']])
    else:
        cmd.extend(['-o', '%(title)s.%(ext)s'])
    
    if options.get('extract_audio', False):
        cmd.append('--extract-audio')
    
    if options.get('audio_format'):
        cmd.extend(['--audio-format', options['audio_format']])
    
    if options.get('audio_quality'):
        cmd.extend(['--audio-quality', options['audio_quality']])
    
    # Playlist options
    if options.get('playlist_items'):
        cmd.extend(['--playlist-items', options['playlist_items']])
    
    if options.get('max_downloads'):
        cmd.extend(['--max-downloads', str(options['max_downloads'])])
    
    if options.get('flat_playlist', False):
        cmd.append('--flat-playlist')
    
    if options.get('playlist_random', False):
        cmd.append('--playlist-random')

    if not options.get('write_playlist_meta', True):
        cmd.append('--no-write-playlist-metafiles')

    # Thumbnail and metadata options
    if options.get('embed_thumbnail', False):
        cmd.append('--embed-thumbnail')

    if options.get('embed_metadata', False):
        cmd.append('--embed-metadata')

    if options.get('write_thumbnail', False):
        cmd.append('--write-thumbnail')

    # Subtitle options
    if options.get('write_subs', False):
        cmd.append('--write-subs')
        if options.get('sub_langs'):
            cmd.extend(['--sub-langs', options['sub_langs']])

    if options.get('write_auto_subs', False):
        cmd.append('--write-auto-subs')

    # Download control options
    if options.get('limit_rate'):
        cmd.extend(['--limit-rate', options['limit_rate']])

    if options.get('retries'):
        cmd.extend(['--retries', str(options['retries'])])

    if options.get('concurrent_fragments'):
        cmd.extend(['--concurrent-fragments', str(options['concurrent_fragments'])])

    # Age restriction
    if options.get('age_limit'):
        cmd.extend(['--age-limit', str(options['age_limit'])])

    # No playlist option
    if options.get('no_playlist', False):
        cmd.append('--no-playlist')

    cmd.append(url)
    
    if not session_id:
        session_id = os.urandom(8).hex()
    
    download_progress[session_id] = {
        'status': 'starting',
        'progress': 0,
        'filename': '',
        'eta': '--:--',
        'speed': '0 KB/s',
        'output': []
    }
    
    def run_download():
        try:
            process = subprocess.Popen(
                cmd, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.STDOUT, 
                universal_newlines=True,
                bufsize=1
            )
            
            download_progress[session_id]['status'] = 'running'
            
            if process.stdout:
                for line in process.stdout:
                    download_progress[session_id]['output'].append(line.strip())
                    
                    # Parse progress information
                    progress_info = parse_yt_dlp_progress(line)
                    if progress_info:
                        if 'progress' in progress_info:
                            download_progress[session_id]['progress'] = progress_info['progress']
                        if 'eta' in progress_info:
                            download_progress[session_id]['eta'] = progress_info['eta']
                        if 'filename' in progress_info:
                            download_progress[session_id]['filename'] = progress_info['filename']
                        if 'status' in progress_info:
                            download_progress[session_id]['status'] = progress_info['status']
                        
                        # Estimate speed based on progress
                        if download_progress[session_id]['progress'] > 0:
                            download_progress[session_id]['speed'] = f"{int(download_progress[session_id]['progress'] * 2)} KB/s"
            
            process.wait()
            
            if process.returncode == 0:
                download_progress[session_id]['status'] = 'completed'
                download_progress[session_id]['progress'] = 100
            else:
                download_progress[session_id]['status'] = 'error'
                download_progress[session_id]['error'] = f'Process exited with code {process.returncode}'
                
        except Exception as e:
            download_progress[session_id]['status'] = 'error'
            download_progress[session_id]['error'] = str(e)
    
    # Run download in background thread
    thread = threading.Thread(target=run_download)
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'success': True, 
        'session_id': session_id,
        'message': 'Download started in background'
    })

@app.route('/progress/<session_id>')
def get_progress(session_id):
    if session_id not in download_progress:
        return jsonify({'error': 'Invalid session ID'}), 404
    
    progress_data = download_progress[session_id]
    return jsonify(progress_data)

@app.route('/playlist-metadata', methods=['POST'])
def get_playlist_metadata():
    data = request.json
    url = data.get('url', '')
    
    if not url:
        return jsonify({'error': 'URL is required'}), 400
    
    # Use yt-dlp to get playlist metadata
    cmd = ['yt-dlp', '--flat-playlist', '--dump-json', url]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            # Parse JSON output from yt-dlp
            videos = []
            for line in result.stdout.strip().split('\n'):
                if line.strip():
                    try:
                        video_data = json.loads(line)
                        videos.append({
                            'id': video_data.get('id'),
                            'title': video_data.get('title'),
                            'duration': video_data.get('duration'),
                            'index': video_data.get('playlist_index'),
                            'url': video_data.get('webpage_url')
                        })
                    except json.JSONDecodeError:
                        continue
            
            return jsonify({'videos': videos})
        else:
            return jsonify({'error': result.stderr}), 500
            
    except subprocess.TimeoutExpired:
        return jsonify({'error': 'Playlist metadata fetch timed out'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/downloads')
def list_downloads():
    """List all downloaded files"""
    try:
        files = []
        # Include video, audio, and subtitle files
        extensions = ('.mp4', '.webm', '.mp3', '.m4a', '.flac', '.wav', '.opus', 
                     '.vtt', '.srt', '.lrc')
        for filename in os.listdir('.'):
            if filename.endswith(extensions):
                file_path = os.path.join('.', filename)
                files.append({
                    'name': filename,
                    'size': os.path.getsize(file_path),
                    'modified': os.path.getmtime(file_path)
                })
        return jsonify({'files': files})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/download-file/<filename>')
def download_file(filename):
    """Serve a downloaded file"""
    try:
        # Security check: prevent directory traversal
        if '..' in filename or '/' in filename or '\\' in filename:
            return jsonify({'error': 'Invalid filename'}), 400

        file_path = os.path.join('.', filename)
        if not os.path.exists(file_path):
            return jsonify({'error': 'File not found'}), 404

        return send_file(file_path, as_attachment=True, download_name=filename)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/video-info', methods=['POST'])
def get_video_info():
    """Get video metadata for preview"""
    data = request.json
    url = data.get('url', '')
    
    if not url:
        return jsonify({'error': 'URL is required'}), 400
    
    # Validate URL format
    if not ('youtube.com' in url or 'youtu.be' in url):
        return jsonify({'error': 'Invalid YouTube URL'}), 400
    
    cmd = ['yt-dlp', '--dump-json', '--no-download', '--skip-download', '--no-playlist', url]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0 and result.stdout:
            try:
                # Get first line and parse JSON
                lines = result.stdout.strip().split('\n')
                if not lines or not lines[0]:
                    return jsonify({'error': 'No video data returned'}), 500
                    
                video_data = json.loads(lines[0])
                
                # Get the best thumbnail available
                thumbnail = video_data.get('thumbnail')
                if not thumbnail and video_data.get('thumbnails'):
                    # Try to get the highest quality thumbnail
                    thumbnails = video_data['thumbnails']
                    if thumbnails:
                        # Sort by preference or get last one (usually highest res)
                        thumbnail = thumbnails[-1].get('url') if isinstance(thumbnails, list) else thumbnails
                
                return jsonify({
                    'id': video_data.get('id'),
                    'title': video_data.get('title'),
                    'channel': video_data.get('channel') or video_data.get('uploader') or video_data.get('uploader_id'),
                    'duration': video_data.get('duration'),
                    'thumbnail': thumbnail,
                    'description': video_data.get('description', '')[:200] + '...' if video_data.get('description') else None
                })
            except json.JSONDecodeError as e:
                return jsonify({'error': f'Failed to parse video data: {str(e)}'}), 500
        else:
            error_msg = result.stderr[:200] if result.stderr else 'Unknown error'
            return jsonify({'error': f'yt-dlp error: {error_msg}'}), 500
    except subprocess.TimeoutExpired:
        return jsonify({'error': 'Request timed out (30s)'}), 500
    except Exception as e:
        return jsonify({'error': f'Server error: {str(e)}'}), 500


@app.route('/thumbnail-proxy')
def thumbnail_proxy():
    """Proxy thumbnail requests to avoid CORS issues"""
    import urllib.request
    thumbnail_url = request.args.get('url')
    
    if not thumbnail_url:
        return jsonify({'error': 'URL parameter required'}), 400
    
    try:
        # Fetch the thumbnail
        req = urllib.request.Request(thumbnail_url, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        with urllib.request.urlopen(req, timeout=10) as response:
            data = response.read()
            content_type = response.headers.get('Content-Type', 'image/jpeg')
            
        return send_file(
            io.BytesIO(data),
            mimetype=content_type,
            as_attachment=False
        )
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.getenv('PORT', 8080)))